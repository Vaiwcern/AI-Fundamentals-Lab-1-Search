#!/bin/bash
pip install pygame
pip install opencv-python
cd source
python main.py